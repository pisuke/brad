###############################
# Blended Radiance brad_io.py #
###############################

##############################
# (c) Francesco Anselmo 2005 #
##############################

#    This file is part of brad (Blended RADiance).
#
#    brad is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.
#
#    brad is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with Foobar; if not, write to the Free Software
#    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

#import pickle

def writeSettings(filename, data):

   sf = open(filename, "w")
   for var in data:
      sf.write("%s\n" % var)
   sf.close()

   """
   pf = open(filename + ".pkl", "w")
   pickle.dump(data, pf)
   pf.close()
   """
   print "settings saved --> ", filename

def getSettings(filename):

   sf = open(filename, "r")
   data = []
   for line in sf.readlines():
      data.append(line[:-len("\n")])
   sf.close()
   """
   pf = open(filename + ".pkl", "r")
   data = pickle.load(pf)
   pf.close()
   """
   print "settings retrieved <-- ", filename
   return data

def zfill(s, n):
   length=len(str(s))
   zeros=""
   for i in range(n-length):
      zeros+="0"
   return zeros+str(s)
