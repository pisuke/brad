""" brad: library browsing input

This class provides a movable window with a
custom number of string buttons and two default extra buttons
OK end ESC (you can set the okEvent and the escEvent in
the class declaration). After the window creation, the user
can access the single string by the self.string list.
For example, if you want a value of second string, you
write name_of_istance.string[1].val
The default tooltip is the index of string: you can use it
to access the string value.
Use this for string input. The numString is the number of string that you want
to see in the input windows. The Deco is a decoration type. Actually you can use
only 0 for simple and 1 for sketch style.
The buttons show the names of the items in the library.

"""

import os
import os.path
import string
import math

from Blender.Draw import *

from BaseWindowClass import BaseWindowClass
#from Picture import *

from brad_lib import *
from brad_i18n import *
from brad_ies import *

registered_data = Blender.Registry.GetKey('brad')
if registered_data:
  brad_path  = registered_data['brad_path']
  debug  = registered_data['debug']

class LumLibwin(BaseWindowClass):


    def __init__(self, LocX, LocY, Width, Heigth, numLines, libdir, Title, okEvent, escEvent, upEvent, downEvent, showEvent, addEvent, modifyEvent, Deco):

        BaseWindowClass.__init__(self,LocX,LocY,Width,Heigth)

        self.type="LumLibWin"

        self.libdir = os.path.join(brad_path, libdir)
        lumlist = loadRadLib(os.path.join(brad_path, libdir))
        lumlist.sort()
        self.files=lumlist
        self.numLines = numLines
        self.Height = 130+self.numLines*66
        self.okE=okEvent
        self.escE=escEvent
        self.upE=upEvent
        self.downE=downEvent
        self.decoration=Deco
        self.title=Title
        self.startItem = 0
        self.endItem = numLines
        self.showBaseE=showEvent
        self.modifyBaseE=modifyEvent
        self.addBaseE=addEvent
        self.showE = []
        self.modifyE = []
        self.addE = []

        if self.numLines > len(self.files):
            self.numLines=len(self.files)

        for i in range(len(self.files)):
                    evt = self.showBaseE+i
                    self.showE.append(self.showBaseE+i)

        for i in range(len(self.files)):
                    evt = self.modifyBaseE+i
                    self.modifyE.append(self.modifyBaseE+i)

        for i in range(len(self.files)):
                    evt = self.addBaseE+i
                    self.addE.append(self.addBaseE+i)

        self.SelectedItem = Create(0)

    #-------------------------------------------#
    #    DRAWING THE BUTTONS                    #
    #-------------------------------------------#

    def drawIt(self):

        if self.Visibility==1:
            if self.decoration == 0:
                self.drawBox()
            else:
                self.drawBoxS()

            #select
            rh = 50
            lib_list_string = self.formatItems(self.files)
            self.SelectedItem = Menu(self.title+" %t|"+lib_list_string, 52, self.LocX + 10, self.LocY-rh, self.Width/3-20, 20, self.SelectedItem.val, self.title)

            #upbutton
            Button("/\\",self.upE,self.LocX+10,self.LocY-70,self.Width-20,16)

            button_dy = 90
            j = 0
            dy = 66
            for i in range(self.startItem, self.endItem):
                if os.path.exists(os.path.join(self.libdir, self.files[i], self.files[i]+".ies")):
                    iesfile=IES(os.path.join(self.libdir, self.files[i], self.files[i]+".ies"))
                    czero=0
                    for ii in range(len(iesfile.horizontalangles)):
                       if iesfile.horizontalangles==0.0:
                          czero=ii
                       ii+=1
                    maxintensity=0.0
                    maxangle=0.0
                    for ii in range(len(iesfile.intensitydata)):
                       for jj in range(len(iesfile.intensitydata[ii])):
                          if iesfile.intensitydata[ii][jj]>maxintensity:
                             maxintensity=iesfile.intensitydata[ii][jj]
                          if iesfile.verticalangles[jj]>maxangle:
                             maxangle=iesfile.verticalangles[jj]
                    #if debug:
                    #   print "czero plan index: ", czero
                    #   print "intensity data: ", iesfile.intensitydata[czero]
                    # draw simple photometric polar curve (available space is 64x64, very tiny!!!)
                    centerx = self.LocX+10+(64/2)
                    centery = self.LocY-90-47-dy*j+32
                    # draw center
                    self.drawLine(centerx -2,
                             centery,
                             centerx+2,
                             centery,
                             1.0,1.0,1.0,4,1.0)
                    # draw polar curve (points!)
                    prevx=None
                    prevy=None
                    for ii in range(len(iesfile.intensitydata[czero])):
                       theta=(-90.0+iesfile.verticalangles[ii])*(math.pi/180.0)
                       rho=iesfile.intensitydata[czero][ii]/maxintensity
                       x=int(rho*math.cos(theta)*32)
                       y=int(rho*math.sin(theta)*32)                       
                       if prevx==None and prevy==None:
                          self.drawLine(
                             centerx+x+1,
                             centery+y+1,
                             centerx+x,
                             centery+y,
                             1.0,0.0,0.0,1,1.0)                       
                       else:
                          self.drawLine(
                             centerx+prevx,
                             centery+prevy,
                             centerx+x,
                             centery+y,
                             1.0,0.0,0.0,1,1.0)
                       prevx=x
                       prevy=y
                    prevx=None
                    prevy=None
                    if maxangle<=90.0:
                       for ii in range(len(iesfile.intensitydata[czero])):
                          theta=(-90.0-iesfile.verticalangles[ii])*(math.pi/180.0)
                          rho=iesfile.intensitydata[czero][ii]/maxintensity
                          x=int(rho*math.cos(theta)*32)
                          y=int(rho*math.sin(theta)*32)
                       if prevx==None and prevy==None:
                          self.drawLine(
                             centerx+x+1,
                             centery+y+1,
                             centerx+x,
                             centery+y,
                             1.0,0.0,0.0,1,1.0)                       
                       else:
                          self.drawLine(
                             centerx+prevx,
                             centery+prevy,
                             centerx+x,
                             centery+y,
                             1.0,0.0,0.0,1,1.0)
                       prevx=x
                       prevy=y
                    #if debug:
                    #   print iesfile.intensitydata[czero]
                    #   print iesfile.verticalangles
                Button(self.files[i],
                    self.showE[i],
                    self.LocX+10+64+5,
                    self.LocY-90-47-dy*j,
                    self.Width-90-64-5,
                    dy-2, msg_UpdateModPreview)
                    #msg_UpdateModPreview+self.files[i])
                Button("+",
                    self.addE[i],
                    self.LocX+10+64+5 + self.Width-80-64-5 + 15,
                    self.LocY-90-47-dy*j,
                    20,
                    dy-2, msg_Add)
                    #msg_Select+self.files[i])
                Button(msg_Mod,
                    self.modifyE[i],
                    self.LocX+10+64+5 + self.Width-80-64-5 + 40,
                    self.LocY-90-47-dy*j,
                    20,
                    dy-2, msg_Modify)
                    #msg_Modify+self.files[i])
                button_dy += dy
                j += 1

            Button("\\/",self.downE,self.LocX+10,self.LocY-button_dy+2,self.Width-20,16)
            Button("OK",self.okE,self.LocX+10,self.LocY-button_dy-25,self.Width/3,20)
            if self.escE!="":
                Button("ESC",self.escE,self.LocX+self.Width-20-self.Width/3,self.LocY-button_dy-25,self.Width/3,20)
            else:
                self.drawText(self.LocX+self.Width-20-self.Width/3,
                    self.LocY-button_dy-20,
                    0,
                    0,
                    0,
                    "::"+str(len(self.files))+"::")

            self.drawTitle(self.title)
            if self.isSelected == 1:
                self.drawBoxHF()


    def scrollUp(self):
        if self.startItem > 0 :
            self.startItem -= 1
            self.endItem -= 1


    def scrollDown(self):
        if self.endItem < len(self.files) :
            self.startItem += 1
            self.endItem += 1

    def formatItems(self, itemlist):
       i=0
       itemmenu = ""
       for item in itemlist:
          itemmenu += string.split(item)[0] + " %x"+ str(i)+"|"
          i+=1
       return itemmenu

    def selectItem(self):
       #event 52
       if self.SelectedItem.val+2 < len(self.files) :
          self.startItem = self.SelectedItem.val-1
          self.endItem = self.SelectedItem.val+2
       else:
          self.startItem = self.SelectedItem.val-2
          self.endItem = self.SelectedItem.val+1

