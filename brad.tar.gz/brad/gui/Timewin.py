""" simulation time settings
"""

#    This file is part of brad (Blended RADiance).
#
#    brad is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.
#
#    brad is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with Foobar; if not, write to the Free Software
#    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

import os
import os.path
import string
import math

import Blender
from Blender.Draw import *

from BaseWindowClass import BaseWindowClass

from brad_i18n import *
from brad_lib import *

class Timewin(BaseWindowClass):

    def __init__(self, LocX, LocY, Width, Heigth, Title, okEvent, Deco):

        BaseWindowClass.__init__(self,LocX,LocY,Width,Heigth)

        self.type="Timewin"

        #self.Height = 110
        self.okE=okEvent
        self.decoration=Deco
        self.title=Title

        """
        self.YearStart = Create(int(strftime("%Y")))
        self.YearEnd = Create(int(strftime("%Y")))
        self.YearStep = Create(int(1))
        """

        self.updateLocation()

    #-------------------------------------------#
    #    DRAWING THE BUTTONS                    #
    #-------------------------------------------#

    def drawIt(self):

      if self.Visibility==1:
        if self.decoration == 0:
                self.drawBox()
        else:
                self.drawBoxS()


        #select location and change location buttons
        rh = 45

        #location settings
        rh = 70

        #north
        rh = 110

        #ok button
        Button(msg_Ok,self.okE,self.LocX+10,self.LocY-self.Height+10,self.Width/3-6,20)

        self.drawTitle(self.title)
        if self.isSelected == 1:
            self.drawBoxHF()
        """

