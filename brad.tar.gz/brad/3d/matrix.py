#!/usr/bin/python

#######################
# (c) Jan Walter 1997 #
#######################

import pntvec
from math import *

# multiply 4X3 matrix (rotation, scaling & translation) with vector
def mulmatvec4x3(m, v):
    r = [0.0, 0.0, 0.0]
    r[0] = v[0]*m[0][0] + v[1]*m[1][0] + v[2]*m[2][0] + m[3][0]
    r[1] = v[0]*m[0][1] + v[1]*m[1][1] + v[2]*m[2][1] + m[3][1]
    r[2] = v[0]*m[0][2] + v[1]*m[1][2] + v[2]*m[2][2] + m[3][2]
    return r


# normalize vector inplace, return length
def vnormlen(v):
    vlen = sqrt(v[0]*v[0] + v[1]*v[1] + v[2]*v[2])
    if vlen!=0.0:
        d = 1.0/vlen
        v[0]*=d;  v[1]*=d;  v[2]*=d
    return vlen


# vector dotproduct
def vdot(v1, v2):
    # dot product
    return v1[0]*v2[0] + v1[1]*v2[1] + v1[2]*v2[2]


# vector crossproduct
def crossp(v1, v2):
    r = [0.0, 0.0, 0.0]
    r[0] = v1[1]*v2[2] - v1[2]*v2[1]
    r[1] = v1[2]*v2[0] - v1[0]*v2[2]
    r[2] = v1[0]*v2[1] - v1[1]*v2[0]
    return r

# get matrix3x3 determinant
def determinant3x3(mtx):
    return vdot(mtx[0], crossp(mtx[1], mtx[2]))

# extract euler rotation, scale & position from a single matrix, 
# doesn't work with non-uniform scaling on parent objects...
def infoFromMatrix(mat):
    mtx = [list(mat[0][:3]), list(mat[1][:3]), list(mat[2][:3])]
    scale = [0.0, 0.0, 0.0]
    scale[0] = vnormlen(mtx[0])
    scale[1] = vnormlen(mtx[1])
    scale[2] = vnormlen(mtx[2])
    # scaling negative?
    if determinant3x3(mtx)<0.0:
        for i in range(3):
            scale[i] *= -1.0
            mtx[i][0] *= -1.0
            mtx[i][1] *= -1.0
            mtx[i][2] *= -1.0
    angle_y = -asin(max(min(mtx[0][2], 1.0), -1.0))
    C = cos(angle_y)
    if C!=0.0: C = 1.0/C
    angle_x = atan2(mtx[1][2] * C, mtx[2][2] * C)
    angle_z = atan2(mtx[0][1] * C, mtx[0][0] * C)
    return (angle_x, angle_y, angle_z), tuple(scale), tuple(mat[3][:3])

# Convert blender matrix to string
def BMTX_TO_STRING(bmtx):
	st = '\t[[%f, %f, %f, %f],\n' % tuple(bmtx[0])
	st += '\t\t\t\t\t\t [%f, %f, %f, %f],\n' % tuple(bmtx[1])
	st += '\t\t\t\t\t\t [%f, %f, %f, %f],\n' % tuple(bmtx[2])
	st += '\t\t\t\t\t\t [%f, %f, %f, %f]] ' % tuple(bmtx[3])
	return st

class Matrix:
    def __init__(self, rows, columns):
        self.rows    = rows
        self.columns = columns
        self.elements = []
        row = [None] * columns
        for i in range(rows):
            self.elements.append(row[:])

    def __getitem__(self, index):
        return self.elements[index]

    def __setitem__(self, index, value):
        self.elements[index] = value

    def __add__(self, matrix):
        if self.__class__ != matrix.__class__:
            raise TypeError, "%s + %s" % (self, matrix)
        elif (self.rows <> matrix.rows) or (self.columns <> matrix.columns):
            raise TypeError, "Matrix(%s,%s) + Matrix(%s,%s)"
        else:
            result = Matrix(self.rows, self.columns)
            for row in xrange(self.rows):
                for column in xrange(self.columns):
                    result[row][column] = (self[row][column] + 
                                           matrix[row][column])
            return result

    def __sub__(self, matrix):
        if self.__class__ != matrix.__class__:
            raise TypeError, "%s - %s" % (self, matrix)
        elif (self.rows <> matrix.rows) or (self.columns <> matrix.columns):
            raise TypeError, "Matrix(%s,%s) - Matrix(%s,%s)"
        else:
            result = Matrix(self.rows, self.columns)
            for row in xrange(self.rows):
                for column in xrange(self.columns):
                    result[row][column] = (self[row][column] - 
                                           matrix[row][column])
            return result

    def __mul__(self, matrix):
        if self.__class__ != matrix.__class__:
            raise TypeError, "%s + %s" % (self, matrix)
        else:
            result = Matrix(self.rows, matrix.columns)
            for row in xrange(self.rows):
                vector1 = apply(pntvec.Vector, tuple(self[row]))
                for column in xrange(matrix.columns):
                    coords = []
                    for i in xrange(matrix.rows):
                        coords.append(matrix[i][column])
                    vector2 = apply(pntvec.Vector, tuple(coords))
                    result[row][column] = vector1 * vector2
            return result

    def __repr__(self):
        string = "Matrix(\n"
        length = len(self.elements)
        for index in range(length):
            if index == length - 1:
                string = string + "\t" + `self.elements[index]` + "\n)"
            else:
                string = string + "\t" + `self.elements[index]` + "\n"
        return string

    def identity(self):
        if self.rows == self.columns:
            self.init(0)
            for i in xrange(self.rows):
                self[i][i] = 1
        else:
            string = "NxN matrix expected, %sx%s matrix found" % (self.rows,
                                                                  self.columns)
            raise TypeError, string

    def init(self, element):
        for i in range(self.rows):
            for j in range(self.columns):
                self[i][j] = element

    def gauss(self):
        for row in range(self.rows):
            factor1 = self[row][row]
            if not factor1:
                for i in range(row+1, self.rows):
                    if self[i][row]:
                        self[i], self[row] = self[row], self[i]
                        factor1 = self[row][row]
                        break;
            if not factor1:
                return row
            others = range(self.rows)
            del others[row]
            for i in others:
                factor2 = self[i][row]
                if factor2:
                    tuple1 = self[row][:]
                    tuple2 = self[i][:]
                    for j in range(self.columns):
                        self[i][j] = (tuple1[j] * factor2 -
                                      tuple2[j] * factor1)

def testMatrix():
    print "======="
    print "Matrix:"
    print "======="
    print
    matrix = Matrix(2, 3)
    print "matrix = %s" % matrix
    print
    matrix1 = Matrix(2, 3)
    matrix2 = Matrix(3, 4)
    value = 0
    for i in range(2):
        for j in range(3):
            matrix1[i][j] = value
            value = value + 1
    value = 0
    for i in range(3):
        for j in range(4):
            matrix2[i][j] = value
            value = value + 1
    print "matrix1 =", matrix1
    print "matrix2 =", matrix2
    print "matrix1 * matrix2 =", matrix1 * matrix2
    matrix1 = Matrix(4, 4)
    matrix2 = Matrix(4, 4)
    matrix1[0] = [0.5, 0.0, 0.0, 0.0]
    matrix1[1] = [0.0, 0.5, 0.0, 0.0]
    matrix1[2] = [0.0, 0.0, 0.5, 0.0]
    matrix1[3] = [0.0, 0.0, 0.0, 1.0]
    matrix2[0] = [1.0, 0.0, 0.0, 0.0]
    matrix2[1] = [0.0, 1.0, 0.0, 0.0]
    matrix2[2] = [0.0, 0.0, 1.0, 0.0]
    matrix2[3] = [0.0, 0.0, 1.0, 1.0]
    print "matrix1 =", matrix1
    print "matrix2 =", matrix2
    print "matrix1 * matrix2 =", matrix1 * matrix2
    print
    row1 = [1, 1, 1]
    row2 = [2, 2, 2]
    matrix[0] = row1
    matrix[1] = row2
    print "matrix = %s" % matrix
    print
    matrix[0][1] = 10
    print "matrix = %s" % matrix
    print
    print "init(element):"
    print "--------------"
    matrix.init(0)
    print "matrix = %s" % matrix
    print
    print "identity():"
    print "-----------"
    matrix = Matrix(3,3)
    matrix.identity()
    print matrix
    print
    print "gauss():"
    print "--------"
    matrix = Matrix(4, 5)
    matrix.init(0)
    matrix[0] = [1, 2, 3, 4, -2]
    matrix[1] = [2, 3, 4, 1,  2]
    matrix[2] = [3, 4, 1, 2,  2]
    matrix[3] = [4, 1, 2, 3, -2]
    print matrix
    matrix.gauss()
    print matrix
    matrix = Matrix(5, 4)
    matrix.init(0)
    matrix[0] = [-1, -3, -12, -5]
    matrix[1] = [-1,  2,   5,  2]
    matrix[2] = [ 0,  5,  17,  7]
    matrix[3] = [ 3, -1,   2,  1]
    matrix[4] = [ 7, -4,  -1,  0]
    print matrix
    matrix.gauss()
    print matrix

if __name__ == "__main__":
    testMatrix()
